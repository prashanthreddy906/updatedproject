export class Dining{
    dReservationNumber:string;
    guestID:string;
    diningType:string;
    arrivalDate:string;
    noOfPeople: string;
    status:string;
    createdDate:string;
    updatedDate:string;
}