export class Resort{
  rReservationNumber:string;
    guestID:string;
    roomType:string;
    arrivalDate:string;
    departureDate:string;
    noOfPeople: string;
    status:string;
    createdDate:string;
    updatedDate:string;
}